# MobileApp2_1
An application called M I C A where users are create a location based message called a "mark", 
marks can be read and rated by other users provided they get close enough in to the mark in the real world to read it.
